var mongoose = require('mongoose');

var TaskSchema = new mongoose.Schema({
    name:String,
    email: String,
    password: String
})

var Task = mongoose.model('prodauth', TaskSchema);

module.exports = Task;