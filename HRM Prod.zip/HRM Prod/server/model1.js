var mongoose = require('mongoose');

var TaskSchema1 = new mongoose.Schema({
    employeeId:{
        type:String,
        default:'EMP7000'
    },
    name:String,
    gender:String,
    maritalStatus:String,
    dob:String,
    emailId:String
})

var Task1 = mongoose.model('prodhrm', TaskSchema1);

module.exports = Task1;