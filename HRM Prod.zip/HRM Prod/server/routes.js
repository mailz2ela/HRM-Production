var express = require('express');
var router = express.Router();
var Task = require('../server/model.js')

router.post('/auth/register', async function (req, res) {
    try {
        var emailExist = await Task.findOne({ email: req.body.email })
        if (emailExist) {
            return res.json("Email already Exit")
        }
        if (!emailExist) {
            var task = new Task({
                name: req.body.name,
                email: req.body.email,
                password: req.body.password
            })
            task.save((err) => {
                if (err) console.log(err)
                res.json('Registered Successfully')
            })
        }

    } catch (err) {
        console.log(err)
    }

})

router.post('/auth/login', async function (req, res) {

    try {

        var userData = await Task.findOne({ email: req.body.email })
        if (!userData) {
            return res.json('Email not Exist, Please register')
        }
        if (userData) {
            var validpass = (userData.password == req.body.password);
            if (userData && !validpass) {
                return res.json('Password is incorrect')
            }
            if (userData && validpass) {
                return res.json('Login Successful')
            }
        }

    } catch (err) {
        console.log(err)
    }



})

router.get('/auth/getall',function(req,res){
    Task.find((err,docs)=>{
        if(err)console.log(err)
        res.json(docs)
    })
})



module.exports = router