var express = require('express');
var app = express();
var mongoose = require('mongoose');
var url = "mongodb://localhost:27017/CRUD"
var router = require('../server/routes.js')
var cors = require('cors');
const router1 = require('./routes1.js');


app.use(cors());
app.use(express.json());
app.use('/', router);
app.use('/home', router1);


app.listen(8080, function (err) {
    if (err) {
        console.log(err)
    } console.log("Sever started at port : 8080")
})

mongoose.connect(url, function (err) {
    if (err) console.log(err)
    console.log("Database connected successfully")
})

