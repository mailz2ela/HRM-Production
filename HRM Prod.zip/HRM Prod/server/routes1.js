var express = require('express');
var router1 = express.Router();
var Task1 = require('../server/model1.js')

router1.post('/addnewpeople', function (req, res) {
    var task = new Task1(req.body)
    task.save((err, doc) => {
        if (err) console.log(err)
        res.json(doc)
    })
})

router1.get('/peopleprofile', function (req, res) {
    Task1.find((err, docs) => {
        if (err) console.log(err)
        res.json(docs)
    })
})

router1.get('/:id', function (req, res) {
    Task1.findById(req.params.id, (err, doc) => {
        if (err) console.log(err)
        res.json(doc)
    })
})

router1.delete('/peopleprofile:id', function (req, res) {
    Task1.findByIdAndDelete(req.params.id, (err, doc) => {
        if (err) console.log(err)
        res.json(doc)
    })
})

router1.put('/peopleprofile:id', function (req, res) {
    Task1.findByIdAndUpdate(req.params.id, req.body, { new: true }, (err, doc) => {
        if (err) console.log(err)
        res.json(doc)
    })
})

module.exports = router1