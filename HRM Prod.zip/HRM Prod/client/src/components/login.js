import React, { useState } from 'react';
import { useFormik } from 'formik';
import * as yup from 'yup';
import '../components/register.css';
import axios from 'axios';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

function Login(props) {


    const formik = useFormik({
        initialValues: {

            email: '',
            password: ''
        },
        validationSchema: yup.object({

            email: yup.string()
                .required('Email is Required'),
            password: yup.string()
                .required('Password is Required')
                .min(5, 'minimum 5 charcters required')
                .max(15, 'maximum 15 characters allowed'),
        }),
        onSubmit: (userData) => {

            axios.post('http://localhost:8080/auth/login', userData).then(res => {

                if (res.data == "Login Successful") {
                    props.history.push('/home')
                    alert("Login Successful, Welcome Home")
                } else {
                    toast(res.data)
                }
            }).catch(err => console.log(err))

        }
    })


    return (
        <div className='container'>


            <div className='loginContainer'>
                <h2>Login Form !</h2>
                <form autoComplete='off' onSubmit={formik.handleSubmit}>

                    <p>Email :</p>
                    <input type='email' name='email' value={formik.values.email} onChange={formik.handleChange}></input>
                    {formik.errors.email ? <span>{formik.errors.email}</span> : null}
                    <p>Password :</p>
                    <input type='password' name='password' value={formik.values.password} onChange={formik.handleChange}></input>
                    {formik.errors.password ? <span>{formik.errors.password}</span> : null}
                    <br></br>
                    <br></br>
                    <input type='submit'></input>

                </form>
                <ToastContainer />
            </div>
        </div>
    )
}

export default Login;