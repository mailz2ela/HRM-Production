import React from 'react';
import '../components/home.css'
import { BrowserRouter as Router, Route, Link, NavLink, Switch } from 'react-router-dom';
import { PromiseProvider } from 'mongoose';

function Home(props) {
    var myClick = ()=>{
        alert("Loggout Successful")
        props.history.push('/')        
    }
    return (
        <div className='homeContainer'>
            <div>
                <ul>
                    <Link to='/home/addnewemployee'><li>Add New People</li></Link>
                    <Link to='/home/peopleprofile'><li>People Profile</li></Link> 
                    <li onClick={myClick}>Loggout</li>               
                </ul>
            </div>
        </div>
    )
}

export default Home;