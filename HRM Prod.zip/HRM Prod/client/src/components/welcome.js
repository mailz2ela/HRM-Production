import React from 'react';
import '../components/welcome.css';
import { BrowserRouter as Router, Route, Link, NavLink, Switch } from 'react-router-dom';

function Welcome() {
  return (
      <div>
            <div className='welcomeContainer'>
                Welcome To HRMS
            </div>
            <div className='authContainer'>
                <ul>
                    <Link to='/auth/register'><li>Register</li></Link>
                    <Link to='/auth/login'><li>Login</li></Link>
                </ul>
            </div>

      </div>
    
  )
}

export default Welcome;