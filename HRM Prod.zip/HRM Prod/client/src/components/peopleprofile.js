import axios from "axios";
import React, { useEffect, useState } from "react";
import '../components/peopleprofile.css'
import { BrowserRouter as Router, Route, Link, NavLink, Switch } from 'react-router-dom';

function PeopleProfile(){

    const [peopleList, SetpeopleList] = useState([]);

    useEffect(()=>{
        axios.get('http://localhost:8080/home/peopleprofile').then(res=>SetpeopleList(res.data)).catch(err=>console.log(err))
    },[])
       var individualEmployee =  peopleList.map((item,index)=>{
        return <table key={index}>            
        <tr>
            <td className='td1'>{item.employeeId}</td>
            <td className='td2'>{item.name}</td>
            <td className='td3'>{item.gender}</td>
            <td className='td4'>{item.maritalStatus}</td>
            <td className='td5'>{item.dob}</td>
            <td className='td6'>{item.emailId}</td>
            <td><Link to={`/home/peopleprofile/editemployee/${item._id}`}><button>Edit</button></Link></td>
            <td><button onClick={()=>{deleteTask(item._id)}}>Delete</button></td>
        </tr>         

    </table>
        })

    var deleteTask = (id)=>{
        axios.delete(`http://localhost:8080/home/peopleprofile${id}`).then(res=>{
            console.log(res.data)
            window.location.reload()
    }).catch(err=>console.log(err))
    }
    return (
        <div>
            <h3>Employee Lists</h3>
            <div>
            <tr>
                <th>EMP ID</th>
                <th>Name</th>
                <th>Gender</th>
                <th>Marital Status</th>
                <th>DOB</th>
                <th>Email ID</th>
            </tr> 
            </div>
            <table>
                <tr>
                    {individualEmployee}
                </tr>
            </table>
        </div>
    )
}

export default PeopleProfile;