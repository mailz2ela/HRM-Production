import React, { useEffect, useState } from "react";
import axios from "axios";
import '../components/addnewemployee.css'


function EditEmployee(props) {

    useEffect(()=>{
        axios.get(`http://localhost:8080/home/${props.match.params.id}`).then(res=>console.log(res.data)).catch(err=>console.log(err))
    },[])

    const [name, Setname] = useState('');
    const [empId, SetempId] = useState('');
    const [gender, Setgender] = useState('');
    const [maritalStatus, SetmaritalStatus] = useState('');
    const [dob, Setdob] = useState('');
    const [email, Setemail] = useState('');

    var mySubmit = (e) => {
        e.preventDefault();
        axios.post('http://localhost:8080/home/addnewpeople', {
            employeeId: empId,
            name: name,
            gender: gender,
            maritalStatus: maritalStatus,
            dob: dob,
            emailId: email
        }).then(res => {
            alert("Employee Added Successfully")
            SetempId('')
            Setdob('')
            Setemail('')
            Setgender('')
            SetmaritalStatus('')
            Setname('')
            console.log(res.data)
        }).catch(err => console.log(err))
    }

    return (
        <div>
            <h2>Edit Employee !</h2>
            <form autoComplete='off' onSubmit={mySubmit}>
                <div>
                    <label>Employee ID : </label><br></br>
                    <input type='text' value={empId} onChange={(event) => { SetempId(event.target.value) }}></input>
                </div>
                <div>
                    <label>Name : </label><br></br>
                    <input type='text' value={name} onChange={(event) => { Setname(event.target.value) }}></input>
                </div>
                <div>
                    <label>Gender : </label><br></br>
                    <select type='text' value={gender} onChange={(event) => { Setgender(event.target.value) }}>
                        <option>--Select--</option>
                        <option>Male</option>
                        <option>Female</option>
                    </select>
                </div>
                <div>
                    <label>Marital Status : </label><br></br>
                    <select type='text' value={maritalStatus} onChange={(event) => { SetmaritalStatus(event.target.value) }}>
                        <option>--Select--</option>
                        <option>Married</option>
                        <option>Single</option>
                    </select>
                </div>
                <div>
                    <label>DOB : </label><br></br>
                    <input type='Date' value={dob} onChange={(event) => { Setdob(event.target.value) }}></input>
                </div>
                <div>
                    <label>Email ID : </label><br></br>
                    <input type='text' value={email} onChange={(event) => { Setemail(event.target.value) }}></input>
                </div><br></br>
                <div>
                    <input type='submit' className='button'></input>
                </div>
            </form>
            <br></br>
            <hr></hr>
        </div>
    )
}

export default EditEmployee;