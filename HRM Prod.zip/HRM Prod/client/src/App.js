import React from 'react';
import Welcome from '../src/components/welcome';
import Register from '../src/components/register';
import Login from '../src/components/login';
import { BrowserRouter as Router, Route, Link, NavLink, Switch } from 'react-router-dom';
import Home from './components/home';
import AddNewEmployee from './components/addnewemployee';
import EditEmployee from './components/editemployee';
import PeopleProfile from './components/peopleprofile';

function App() {
  return (
    <div>
      <Route path='/' component={Welcome}></Route>
      <Route path='/auth/register/' component={Register}></Route>
      <Route path='/auth/login/' component={Login}></Route>
      <Route path='/home' component={Home}></Route>
      <Route path='/home/addnewemployee' component={AddNewEmployee}></Route>
      <Route path='/home/peopleprofile/editemployee' render={(props)=><EditEmployee {...props}/>}></Route>
      <Route exact path='/home/peopleprofile' component={PeopleProfile}></Route>
    </div>
  )
}

export default App; 